@echo off
title Guardian APK Builder
color 0A

echo.
echo  ============================================
echo   GUARDIAN APK BUILDER - Auto Setup
echo  ============================================
echo.

:: Use Desktop\X as base (where project already is)
set BASE=%USERPROFILE%\Desktop\X
set JDK_DIR=%BASE%\jdk17
set SDK_DIR=%BASE%\sdk
set PROJECT_DIR=%BASE%\GuardianApp

echo Base directory: %BASE%
echo.

echo [1/6] Creating directories...
mkdir "%JDK_DIR%" 2>nul
mkdir "%SDK_DIR%" 2>nul
echo Done.

echo.
echo [2/6] Downloading JDK 17 (takes 2-3 min)...
powershell -Command "& { $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://download.java.net/java/GA/jdk17.0.2/dfd4a8d0985749f896bed50d99f26a2/8/GPL/openjdk-17.0.2_windows-x64_bin.zip' -OutFile '%BASE%\jdk17.zip' }"
if not exist "%BASE%\jdk17.zip" (
    echo JDK download failed - trying alternative...
    powershell -Command "& { $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.9+9/OpenJDK17U-jdk_x64_windows_hotspot_17.0.9_9.zip' -OutFile '%BASE%\jdk17.zip' }"
)
echo Extracting JDK...
powershell -Command "& { $ProgressPreference='SilentlyContinue'; Expand-Archive -Path '%BASE%\jdk17.zip' -DestinationPath '%JDK_DIR%' -Force }"
echo JDK Done.

echo.
echo [3/6] Downloading Android SDK Command Line Tools...
powershell -Command "& { $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip' -OutFile '%BASE%\cmdtools.zip' }"
echo Extracting SDK tools...
powershell -Command "& { $ProgressPreference='SilentlyContinue'; Expand-Archive -Path '%BASE%\cmdtools.zip' -DestinationPath '%SDK_DIR%\cmdline-tools' -Force }"
echo SDK Done.

echo.
echo [4/6] Setting up environment...
:: Find JDK bin folder
for /d %%i in ("%JDK_DIR%\jdk*") do set JAVA_HOME=%%i
if "%JAVA_HOME%"=="" (
    for /d %%i in ("%JDK_DIR%\*") do set JAVA_HOME=%%i
)
set ANDROID_HOME=%SDK_DIR%
set PATH=%JAVA_HOME%\bin;%SDK_DIR%\cmdline-tools\cmdline-tools\bin;%SDK_DIR%\platform-tools;%PATH%
echo JAVA_HOME = %JAVA_HOME%
java -version
echo Done.

echo.
echo [5/6] Installing Android SDK platforms and build tools...
mkdir "%SDK_DIR%\licenses" 2>nul
echo 24333f8a63b6825ea9c5514f83c2829b004d1fee > "%SDK_DIR%\licenses\android-sdk-license"
echo 84831b9409646a918e30573bab4c9c91346d8abd >> "%SDK_DIR%\licenses\android-sdk-license"
call sdkmanager --sdk_root="%ANDROID_HOME%" "platform-tools" "platforms;android-34" "build-tools;34.0.0" 2>nul
echo Done.

echo.
echo [6/6] Building Guardian APK...
cd /d "%PROJECT_DIR%"

:: Write local.properties
echo sdk.dir=%ANDROID_HOME:\=\\% > local.properties
echo local.properties written.

:: Run Gradle
echo Running Gradle build...
call gradlew.bat assembleDebug --no-daemon --stacktrace

echo.
echo  ============================================
set APK_PATH=%PROJECT_DIR%\app\build\outputs\apk\debug\app-debug.apk
if exist "%APK_PATH%" (
    echo   SUCCESS! APK Built!
    copy "%APK_PATH%" "%USERPROFILE%\Desktop\Guardian.apk"
    echo   Guardian.apk saved to Desktop!
) else (
    echo   Build failed - check errors above
)
echo  ============================================
pause

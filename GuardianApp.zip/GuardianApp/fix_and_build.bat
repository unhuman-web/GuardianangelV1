@echo off
title Guardian Fix and Build
color 0A

echo Fixing Gradle wrapper...
if not exist "gradle\wrapper" mkdir "gradle\wrapper"

echo Downloading gradle-wrapper.jar...
powershell -Command "& { $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://github.com/gradle/gradle/raw/v8.2.0/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle\wrapper\gradle-wrapper.jar' }"

if not exist "gradle\wrapper\gradle-wrapper.jar" (
    echo Trying alternative download...
    powershell -Command "& { $ProgressPreference='SilentlyContinue'; $url='https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar'; (New-Object Net.WebClient).DownloadFile($url,'gradle\wrapper\gradle-wrapper.jar') }"
)

echo Setting up environment...
set JAVA_HOME=C:\Program Files\Microsoft\jdk-17.0.19.10-hotspot
set ANDROID_HOME=C:\Android\android-sdk
set PATH=%JAVA_HOME%\bin;%ANDROID_HOME%\tools;%ANDROID_HOME%\platform-tools;%PATH%

echo Writing local.properties...
echo sdk.dir=C:\\Android\\android-sdk > local.properties

echo Accepting SDK licenses...
mkdir "%ANDROID_HOME%\licenses" 2>nul
echo 24333f8a63b6825ea9c5514f83c2829b004d1fee > "%ANDROID_HOME%\licenses\android-sdk-license"
echo 84831b9409646a918e30573bab4c9c91346d8abd >> "%ANDROID_HOME%\licenses\android-sdk-license"

echo Installing required SDK platforms...
call "%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager.bat" "platforms;android-34" "build-tools;34.0.0" 2>nul
call "%ANDROID_HOME%\tools\bin\sdkmanager.bat" "platforms;android-34" "build-tools;34.0.0" 2>nul

echo Building APK...
call gradlew.bat assembleDebug --no-daemon

echo.
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo ============================================
    echo  SUCCESS! APK Built!
    copy "app\build\outputs\apk\debug\app-debug.apk" "%USERPROFILE%\Desktop\Guardian.apk"
    echo  Guardian.apk saved to Desktop!
    echo ============================================
) else (
    echo ============================================
    echo  Build failed - check errors above
    echo ============================================
)
pause

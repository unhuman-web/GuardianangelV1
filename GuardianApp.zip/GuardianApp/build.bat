@echo off
title Guardian APK Builder
color 0A

echo.
echo  ============================================
echo   GUARDIAN APK BUILDER - Auto Setup
echo  ============================================
echo.

:: Set paths
set BASE=C:\GuardianBuild
set JDK_URL=https://download.java.net/java/GA/jdk17.0.2/dfd4a8d0985749f896bed50d99f26a2/8/GPL/openjdk-17.0.2_windows-x64_bin.zip
set SDK_URL=https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip
set JDK_DIR=%BASE%\jdk17
set SDK_DIR=%BASE%\sdk
set PROJECT_DIR=%BASE%\GuardianApp

echo [1/6] Creating build directory...
mkdir %BASE% 2>nul
mkdir %JDK_DIR% 2>nul
mkdir %SDK_DIR% 2>nul
echo Done.

echo.
echo [2/6] Downloading JDK 17 (this takes 2-3 min)...
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%JDK_URL%' -OutFile '%BASE%\jdk17.zip' -UseBasicParsing}"
echo Extracting JDK...
powershell -Command "Expand-Archive -Path '%BASE%\jdk17.zip' -DestinationPath '%JDK_DIR%' -Force"
echo Done.

echo.
echo [3/6] Downloading Android SDK Command Line Tools...
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%SDK_URL%' -OutFile '%BASE%\cmdtools.zip' -UseBasicParsing}"
echo Extracting SDK tools...
powershell -Command "Expand-Archive -Path '%BASE%\cmdtools.zip' -DestinationPath '%SDK_DIR%\cmdline-tools' -Force"
echo Done.

echo.
echo [4/6] Setting environment variables...
:: Find JDK folder inside extracted zip
for /d %%i in (%JDK_DIR%\jdk*) do set JAVA_HOME=%%i
set ANDROID_HOME=%SDK_DIR%
set PATH=%JAVA_HOME%\bin;%SDK_DIR%\cmdline-tools\cmdline-tools\bin;%SDK_DIR%\platform-tools;%PATH%
echo JAVA_HOME = %JAVA_HOME%
echo Done.

echo.
echo [5/6] Accepting Android SDK licenses and installing build tools...
echo y | call sdkmanager --sdk_root=%ANDROID_HOME% "platform-tools" "platforms;android-34" "build-tools;34.0.0" 2>nul
echo Done.

echo.
echo [6/6] Building Guardian APK...
cd /d %PROJECT_DIR%

:: Set local.properties for SDK path
echo sdk.dir=%ANDROID_HOME:\=\\% > local.properties

:: Run Gradle build
call gradlew.bat assembleDebug

echo.
echo  ============================================
if exist "%PROJECT_DIR%\app\build\outputs\apk\debug\app-debug.apk" (
    echo   SUCCESS! APK built!
    echo   Location:
    echo   %PROJECT_DIR%\app\build\outputs\apk\debug\app-debug.apk
    echo.
    echo   Copying to Desktop...
    copy "%PROJECT_DIR%\app\build\outputs\apk\debug\app-debug.apk" "%USERPROFILE%\Desktop\Guardian.apk"
    echo   Guardian.apk is now on your Desktop!
) else (
    echo   Build failed - see errors above
)
echo  ============================================
echo.
pause

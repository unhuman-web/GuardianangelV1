package com.guardian.app;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class NotificationService extends NotificationListenerService {

    private static final String TAG = "GuardianNotif";
    public static final List<JSONObject> recentNotifications = new ArrayList<>();
    private static final int MAX_NOTIFS = 50;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            android.app.Notification notif = sbn.getNotification();
            android.os.Bundle extras = notif.extras;

            String title = extras.getString(android.app.Notification.EXTRA_TITLE, "");
            String text = extras.getCharSequence(android.app.Notification.EXTRA_TEXT, "").toString();
            String pkg = sbn.getPackageName();

            // Get app name from package
            String appName = pkg;
            try {
                appName = getPackageManager()
                    .getApplicationLabel(
                        getPackageManager().getApplicationInfo(pkg, 0))
                    .toString();
            } catch (Exception ignored) {}

            JSONObject obj = new JSONObject();
            obj.put("app", appName);
            obj.put("package", pkg);
            obj.put("title", title);
            obj.put("text", text);
            obj.put("time", System.currentTimeMillis());

            // Keep last 50
            if (recentNotifications.size() >= MAX_NOTIFS) {
                recentNotifications.remove(0);
            }
            recentNotifications.add(obj);

            Log.d(TAG, "Notification: " + appName + " - " + title);

        } catch (Exception e) {
            Log.e(TAG, "Notification error", e);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}

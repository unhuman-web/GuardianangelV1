package com.guardian.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GuardianService extends Service {

    private static final String TAG = "GuardianService";
    private static final String CHANNEL_ID = "guardian_channel";
    private static final int NOTIF_ID = 1;
    private static final int HTTP_PORT = 8765;
    private static final int WS_PORT = 8766;

    private ServerSocket httpServer;
    private ServerSocket wsServer;
    private ExecutorService executor;
    private PowerManager.WakeLock wakeLock;
    private LocationManager locationManager;
    private Location lastLocation;
    private boolean running = false;

    // Connected WebSocket clients
    private final java.util.Set<Socket> wsClients = java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newCachedThreadPool();
        createNotificationChannel();
        acquireWakeLock();
        startLocationUpdates();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification());
        running = true;

        // Start HTTP server
        executor.execute(this::runHttpServer);

        // Start WebSocket server
        executor.execute(this::runWebSocketServer);

        return START_STICKY; // Restart if killed
    }

    // ─── NOTIFICATION ───────────────────────────────────────────────────────

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Guardian Remote Access",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Guardian is running");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Guardian Active")
            .setContentText("Remote access running — tap to open")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    // ─── HTTP SERVER ────────────────────────────────────────────────────────

    private void runHttpServer() {
        try {
            httpServer = new ServerSocket(HTTP_PORT);
            Log.d(TAG, "HTTP server started on port " + HTTP_PORT);

            while (running) {
                try {
                    Socket client = httpServer.accept();
                    executor.execute(() -> handleHttpClient(client));
                } catch (IOException e) {
                    if (running) Log.e(TAG, "HTTP accept error", e);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "HTTP server error", e);
        }
    }

    private void handleHttpClient(Socket client) {
        try {
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(client.getInputStream()));
            OutputStream out = client.getOutputStream();

            // Read request line
            String requestLine = reader.readLine();
            if (requestLine == null) return;

            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;

            String method = parts[0];
            String path = parts[1];

            // Read headers
            Map<String, String> headers = new HashMap<>();
            String line;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                int colon = line.indexOf(':');
                if (colon > 0) {
                    headers.put(line.substring(0, colon).trim().toLowerCase(),
                        line.substring(colon + 1).trim());
                }
            }

            // Check for WebSocket upgrade
            if ("GET".equals(method) && "websocket".equals(headers.get("upgrade"))) {
                handleWebSocketUpgrade(client, headers);
                return;
            }

            // Route HTTP requests
            String response = routeRequest(method, path, reader);
            sendHttpResponse(out, response);
            client.close();

        } catch (IOException e) {
            Log.e(TAG, "Client handler error", e);
        }
    }

    private String routeRequest(String method, String path, BufferedReader reader) {
        try {
            // Dashboard HTML
            if ("GET".equals(method) && ("/".equals(path) || "/dashboard".equals(path))) {
                return getDashboardHtml();
            }

            // API routes
            if (path.startsWith("/api/")) {
                return handleApiRequest(method, path.substring(5), reader);
            }

            return jsonResponse(404, "Not found");

        } catch (Exception e) {
            return jsonResponse(500, e.getMessage());
        }
    }

    private String handleApiRequest(String method, String endpoint, BufferedReader reader) {
        try {
            switch (endpoint) {

                case "info":
                    return getDeviceInfo();

                case "location":
                    return getLocationJson();

                case "files":
                    return listFiles("/sdcard/");

                case "apps":
                    return getInstalledApps();

                case "battery":
                    return getBatteryInfo();

                case "screenshot":
                    return takeScreenshot();

                case "lock":
                    lockScreen();
                    return jsonResponse(200, "Screen locked");

                case "home":
                    pressHome();
                    return jsonResponse(200, "Home pressed");

                case "back":
                    pressBack();
                    return jsonResponse(200, "Back pressed");

                default:
                    return jsonResponse(404, "Unknown endpoint: " + endpoint);
            }
        } catch (Exception e) {
            return jsonResponse(500, e.getMessage());
        }
    }

    // ─── DEVICE INFO ────────────────────────────────────────────────────────

    private String getDeviceInfo() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("model", Build.MODEL);
        json.put("manufacturer", Build.MANUFACTURER);
        json.put("android", Build.VERSION.RELEASE);
        json.put("sdk", Build.VERSION.SDK_INT);
        json.put("device", Build.DEVICE);
        json.put("status", "online");
        return httpOk(json.toString());
    }

    private String getBatteryInfo() throws JSONException {
        Intent batteryIntent = registerReceiver(null,
            new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = batteryIntent != null ?
            batteryIntent.getIntExtra("level", -1) : -1;
        int scale = batteryIntent != null ?
            batteryIntent.getIntExtra("scale", -1) : -1;
        int status = batteryIntent != null ?
            batteryIntent.getIntExtra("status", -1) : -1;

        JSONObject json = new JSONObject();
        json.put("level", scale > 0 ? (level * 100 / scale) : -1);
        json.put("charging", status == 2);
        return httpOk(json.toString());
    }

    // ─── LOCATION ───────────────────────────────────────────────────────────

    private void startLocationUpdates() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(@NonNull Location location) {
                    lastLocation = location;
                    broadcastLocation(location);
                }
                @Override public void onProviderEnabled(@NonNull String provider) {}
                @Override public void onProviderDisabled(@NonNull String provider) {}
                @Override public void onStatusChanged(String p, int s, Bundle e) {}
            };

            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 10000, 10, listener);
            locationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, 10000, 10, listener);

            // Get last known
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            lastLocation = gps != null ? gps : net;

        } catch (SecurityException e) {
            Log.e(TAG, "Location permission denied", e);
        }
    }

    private String getLocationJson() throws JSONException {
        JSONObject json = new JSONObject();
        if (lastLocation != null) {
            json.put("success", true);
            json.put("lat", lastLocation.getLatitude());
            json.put("lng", lastLocation.getLongitude());
            json.put("accuracy", lastLocation.getAccuracy());
            json.put("speed", lastLocation.getSpeed());
            json.put("time", lastLocation.getTime());
        } else {
            json.put("success", false);
            json.put("error", "Location not available yet");
        }
        return httpOk(json.toString());
    }

    private void broadcastLocation(Location loc) {
        try {
            JSONObject msg = new JSONObject();
            msg.put("type", "location");
            msg.put("lat", loc.getLatitude());
            msg.put("lng", loc.getLongitude());
            msg.put("speed", loc.getSpeed());
            broadcastWs(msg.toString());
        } catch (JSONException e) {
            Log.e(TAG, "Location broadcast error", e);
        }
    }

    // ─── FILES ──────────────────────────────────────────────────────────────

    private String listFiles(String path) throws JSONException {
        File dir = new File(path);
        JSONArray arr = new JSONArray();

        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    JSONObject obj = new JSONObject();
                    obj.put("name", f.getName());
                    obj.put("type", f.isDirectory() ? "folder" : "file");
                    obj.put("size", f.length());
                    obj.put("path", f.getAbsolutePath());
                    obj.put("modified", f.lastModified());
                    arr.put(obj);
                }
            }
        }

        JSONObject result = new JSONObject();
        result.put("path", path);
        result.put("files", arr);
        return httpOk(result.toString());
    }

    // ─── APPS ───────────────────────────────────────────────────────────────

    private String getInstalledApps() throws JSONException {
        List<android.content.pm.ApplicationInfo> apps =
            getPackageManager().getInstalledApplications(
                android.content.pm.PackageManager.GET_META_DATA);

        JSONArray arr = new JSONArray();
        for (android.content.pm.ApplicationInfo app : apps) {
            if ((app.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0) {
                JSONObject obj = new JSONObject();
                obj.put("package", app.packageName);
                obj.put("name", getPackageManager().getApplicationLabel(app).toString());
                arr.put(obj);
            }
        }

        JSONObject result = new JSONObject();
        result.put("apps", arr);
        return httpOk(result.toString());
    }

    // ─── SCREEN CONTROLS ────────────────────────────────────────────────────

    private void lockScreen() {
        android.app.admin.DevicePolicyManager dpm =
            (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        if (dpm != null) dpm.lockNow();
    }

    private void pressHome() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void pressBack() {
        // Requires accessibility service for full back press
        Log.d(TAG, "Back pressed (requires accessibility)");
    }

    // ─── SCREENSHOT ─────────────────────────────────────────────────────────

    private String takeScreenshot() {
        // Requires MediaProjection — user grants once via prompt
        // GuardianProjectionActivity handles this
        Intent intent = new Intent(this, GuardianProjectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        return jsonResponse(200, "Screenshot requested — check /api/screenshot-result");
    }

    // ─── WEBSOCKET ──────────────────────────────────────────────────────────

    private void runWebSocketServer() {
        try {
            wsServer = new ServerSocket(WS_PORT);
            Log.d(TAG, "WebSocket server started on port " + WS_PORT);

            while (running) {
                try {
                    Socket client = wsServer.accept();
                    executor.execute(() -> handleWsClient(client));
                } catch (IOException e) {
                    if (running) Log.e(TAG, "WS accept error", e);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "WS server error", e);
        }
    }

    private void handleWsClient(Socket client) {
        try {
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(client.getInputStream()));
            OutputStream out = client.getOutputStream();

            // Read HTTP upgrade request
            StringBuilder requestBuilder = new StringBuilder();
            String line;
            String wsKey = null;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                requestBuilder.append(line).append("\r\n");
                if (line.startsWith("Sec-WebSocket-Key:")) {
                    wsKey = line.substring(18).trim();
                }
            }

            if (wsKey == null) return;

            // Send WebSocket handshake
            String acceptKey = generateWsAcceptKey(wsKey);
            String handshake = "HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                "Sec-WebSocket-Accept: " + acceptKey + "\r\n\r\n";
            out.write(handshake.getBytes());
            out.flush();

            wsClients.add(client);
            Log.d(TAG, "WS client connected. Total: " + wsClients.size());

            // Send welcome
            sendWsFrame(out, "{\"type\":\"connected\",\"message\":\"Guardian WebSocket ready\"}");

            // Read frames (keepalive/commands)
            while (running && !client.isClosed()) {
                try {
                    int b1 = client.getInputStream().read();
                    if (b1 == -1) break;
                    // Handle ping/pong etc - simplified
                    Thread.sleep(100);
                } catch (Exception e) {
                    break;
                }
            }

            wsClients.remove(client);
            client.close();

        } catch (Exception e) {
            Log.e(TAG, "WS client error", e);
            wsClients.remove(client);
        }
    }

    private String generateWsAcceptKey(String key) {
        try {
            String combined = key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] hash = md.digest(combined.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private void sendWsFrame(OutputStream out, String message) throws IOException {
        byte[] payload = message.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream frame = new ByteArrayOutputStream();
        frame.write(0x81); // Text frame
        if (payload.length <= 125) {
            frame.write(payload.length);
        } else if (payload.length <= 65535) {
            frame.write(126);
            frame.write((payload.length >> 8) & 0xFF);
            frame.write(payload.length & 0xFF);
        }
        frame.write(payload);
        out.write(frame.toByteArray());
        out.flush();
    }

    private void broadcastWs(String message) {
        synchronized (wsClients) {
            for (Socket client : wsClients) {
                try {
                    sendWsFrame(client.getOutputStream(), message);
                } catch (IOException e) {
                    wsClients.remove(client);
                }
            }
        }
    }

    private void handleWebSocketUpgrade(Socket client, Map<String, String> headers) {
        handleWsClient(client);
    }

    // ─── DASHBOARD HTML ─────────────────────────────────────────────────────

    private String getDashboardHtml() {
        String html = "<!DOCTYPE html><html><head>" +
            "<title>Guardian Dashboard</title>" +
            "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>" +
            "* { box-sizing: border-box; margin: 0; padding: 0; }" +
            "body { background: #0a0a0f; color: #fff; font-family: monospace; }" +
            ".header { background: #111; padding: 16px 24px; border-bottom: 1px solid #222; display: flex; align-items: center; gap: 12px; }" +
            ".dot { width: 10px; height: 10px; border-radius: 50%; background: #00ff88; animation: pulse 2s infinite; }" +
            "@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }" +
            ".grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; padding: 24px; }" +
            ".card { background: #111; border: 1px solid #222; border-radius: 12px; padding: 20px; }" +
            ".card h3 { color: #00ff88; font-size: 12px; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 16px; }" +
            ".btn { background: rgba(0,255,136,0.1); border: 1px solid rgba(0,255,136,0.3); color: #00ff88; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-family: monospace; margin: 4px; font-size: 12px; }" +
            ".btn:hover { background: rgba(0,255,136,0.2); }" +
            ".btn.red { background: rgba(255,59,59,0.1); border-color: rgba(255,59,59,0.3); color: #ff3b3b; }" +
            ".info { color: #888; font-size: 12px; margin-top: 8px; line-height: 1.8; }" +
            ".info span { color: #fff; }" +
            "#screenshot { max-width: 100%; border-radius: 8px; margin-top: 12px; border: 1px solid #222; }" +
            "#map { width: 100%; height: 200px; background: #0a0a0f; border-radius: 8px; border: 1px solid #222; display: flex; align-items: center; justify-content: center; color: #444; font-size: 12px; margin-top: 12px; }" +
            "#fileList { margin-top: 12px; max-height: 300px; overflow-y: auto; }" +
            ".file-item { display: flex; align-items: center; gap: 8px; padding: 8px; border-bottom: 1px solid #1a1a1a; font-size: 12px; cursor: pointer; }" +
            ".file-item:hover { background: #1a1a1a; }" +
            "#appList { margin-top: 12px; max-height: 300px; overflow-y: auto; }" +
            ".app-item { display: flex; align-items: center; justify-content: space-between; padding: 8px; border-bottom: 1px solid #1a1a1a; font-size: 12px; }" +
            "#log { background: #050508; border: 1px solid #1a1a1a; border-radius: 8px; padding: 12px; height: 120px; overflow-y: auto; font-size: 11px; color: #00ff88; margin-top: 12px; }" +
            "</style></head><body>" +

            "<div class='header'>" +
            "<div class='dot'></div>" +
            "<span style='font-size:16px;font-weight:bold;'>GUARDIAN</span>" +
            "<span id='connStatus' style='margin-left:auto;color:#888;font-size:12px;'>Connecting...</span>" +
            "</div>" +

            "<div class='grid'>" +

            // Device Info Card
            "<div class='card'>" +
            "<h3>Device Info</h3>" +
            "<div class='info' id='deviceInfo'>Loading...</div>" +
            "<button class='btn' onclick='loadInfo()'>Refresh</button>" +
            "</div>" +

            // Screenshot Card
            "<div class='card'>" +
            "<h3>Screenshot</h3>" +
            "<button class='btn' onclick='takeScreenshot()'>Take Screenshot</button>" +
            "<img id='screenshot' style='display:none'/>" +
            "</div>" +

            // Location Card
            "<div class='card'>" +
            "<h3>Live Location</h3>" +
            "<div class='info' id='locationInfo'>Loading...</div>" +
            "<div id='map'>📍 Location will appear here</div>" +
            "<button class='btn' onclick='loadLocation()'>Refresh Location</button>" +
            "</div>" +

            // Controls Card
            "<div class='card'>" +
            "<h3>Remote Controls</h3>" +
            "<button class='btn' onclick='api(\"lock\")'>🔒 Lock Screen</button>" +
            "<button class='btn' onclick='api(\"home\")'>🏠 Home Button</button>" +
            "<button class='btn' onclick='api(\"back\")'>◀ Back Button</button>" +
            "<button class='btn red' onclick='if(confirm(\"Reboot?\"))api(\"reboot\")'>🔄 Reboot</button>" +
            "</div>" +

            // Files Card
            "<div class='card'>" +
            "<h3>File Manager</h3>" +
            "<button class='btn' onclick='loadFiles(\"/sdcard/\")'>Browse Files</button>" +
            "<div id='fileList'></div>" +
            "</div>" +

            // Apps Card
            "<div class='card'>" +
            "<h3>Installed Apps</h3>" +
            "<button class='btn' onclick='loadApps()'>Load Apps</button>" +
            "<div id='appList'></div>" +
            "</div>" +

            // Log Card
            "<div class='card' style='grid-column:1/-1'>" +
            "<h3>Live Log</h3>" +
            "<div id='log'></div>" +
            "</div>" +

            "</div>" +

            "<script>" +
            "const BASE = '';" +
            "let ws;" +

            "function log(msg) {" +
            "  const el = document.getElementById('log');" +
            "  el.innerHTML += new Date().toLocaleTimeString() + ' → ' + msg + '<br>';" +
            "  el.scrollTop = el.scrollHeight;" +
            "}" +

            "function connectWs() {" +
            "  ws = new WebSocket('ws://' + location.hostname + ':8766');" +
            "  ws.onopen = () => { document.getElementById('connStatus').textContent = '🟢 Connected'; log('WebSocket connected'); };" +
            "  ws.onclose = () => { document.getElementById('connStatus').textContent = '🔴 Disconnected'; setTimeout(connectWs, 3000); };" +
            "  ws.onmessage = (e) => { const d = JSON.parse(e.data); log('WS: ' + JSON.stringify(d)); if(d.type==='location') updateMapLink(d.lat, d.lng); };" +
            "}" +

            "async function api(endpoint, method='GET') {" +
            "  log('→ ' + endpoint);" +
            "  const r = await fetch('/api/' + endpoint, {method});" +
            "  const d = await r.json();" +
            "  log('← ' + JSON.stringify(d));" +
            "  return d;" +
            "}" +

            "async function loadInfo() {" +
            "  const d = await api('info');" +
            "  document.getElementById('deviceInfo').innerHTML = " +
            "    'Model: <span>' + d.model + '</span><br>' +" +
            "    'Android: <span>' + d.android + '</span><br>' +" +
            "    'Manufacturer: <span>' + d.manufacturer + '</span>';" +
            "  const b = await api('battery');" +
            "  document.getElementById('deviceInfo').innerHTML += '<br>Battery: <span>' + b.level + '%' + (b.charging?' ⚡':'') + '</span>';" +
            "}" +

            "async function loadLocation() {" +
            "  const d = await api('location');" +
            "  if(d.success) {" +
            "    document.getElementById('locationInfo').innerHTML = 'Lat: <span>' + d.lat.toFixed(6) + '</span><br>Lng: <span>' + d.lng.toFixed(6) + '</span><br>Speed: <span>' + (d.speed*3.6).toFixed(1) + ' km/h</span><br>Accuracy: <span>' + d.accuracy.toFixed(0) + 'm</span>';" +
            "    updateMapLink(d.lat, d.lng);" +
            "  } else {" +
            "    document.getElementById('locationInfo').innerHTML = 'Location unavailable';" +
            "  }" +
            "}" +

            "function updateMapLink(lat, lng) {" +
            "  document.getElementById('map').innerHTML = '<a href=\"https://maps.google.com/?q=' + lat + ',' + lng + '\" target=\"_blank\" style=\"color:#00ff88\">📍 View on Google Maps<br><small>' + lat.toFixed(6) + ', ' + lng.toFixed(6) + '</small></a>';" +
            "}" +

            "async function takeScreenshot() {" +
            "  log('Taking screenshot...');" +
            "  const r = await fetch('/api/screenshot');" +
            "  if(r.ok) {" +
            "    const blob = await r.blob();" +
            "    const url = URL.createObjectURL(blob);" +
            "    const img = document.getElementById('screenshot');" +
            "    img.src = url; img.style.display='block';" +
            "  }" +
            "}" +

            "async function loadFiles(path) {" +
            "  const d = await api('files?path=' + encodeURIComponent(path));" +
            "  const list = document.getElementById('fileList');" +
            "  list.innerHTML = '';" +
            "  if(d.files) d.files.forEach(f => {" +
            "    const div = document.createElement('div');" +
            "    div.className = 'file-item';" +
            "    div.innerHTML = (f.type==='folder'?'📁':'📄') + ' ' + f.name + '<span style=\"margin-left:auto;color:#555\">' + (f.size > 0 ? (f.size/1024).toFixed(1)+'KB' : '') + '</span>';" +
            "    if(f.type==='folder') div.onclick = () => loadFiles(f.path);" +
            "    list.appendChild(div);" +
            "  });" +
            "}" +

            "async function loadApps() {" +
            "  const d = await api('apps');" +
            "  const list = document.getElementById('appList');" +
            "  list.innerHTML = '';" +
            "  if(d.apps) d.apps.forEach(a => {" +
            "    const div = document.createElement('div');" +
            "    div.className = 'app-item';" +
            "    div.innerHTML = '<span>' + a.name + '</span><small style=\"color:#555\">' + a.package + '</small>';" +
            "    list.appendChild(div);" +
            "  });" +
            "}" +

            "// Init" +
            "connectWs();" +
            "loadInfo();" +
            "loadLocation();" +
            "setInterval(loadLocation, 30000);" +
            "</script></body></html>";

        return "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: " +
            html.length() + "\r\n\r\n" + html;
    }

    // ─── HTTP HELPERS ───────────────────────────────────────────────────────

    private void sendHttpResponse(OutputStream out, String response) throws IOException {
        out.write(response.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private String httpOk(String body) {
        return "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: " +
            body.length() + "\r\n\r\n" + body;
    }

    private String jsonResponse(int code, String message) {
        String body = "{\"status\":" + code + ",\"message\":\"" + message + "\"}";
        String status = code == 200 ? "200 OK" : code == 404 ? "404 Not Found" : "500 Internal Server Error";
        return "HTTP/1.1 " + status + "\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: " +
            body.length() + "\r\n\r\n" + body;
    }

    // ─── WAKE LOCK ──────────────────────────────────────────────────────────

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Guardian::WakeLock");
        wakeLock.acquire();
    }

    // ─── LIFECYCLE ──────────────────────────────────────────────────────────

    @Override
    public void onDestroy() {
        super.onDestroy();
        running = false;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        try { if (httpServer != null) httpServer.close(); } catch (IOException e) {}
        try { if (wsServer != null) wsServer.close(); } catch (IOException e) {}
        executor.shutdown();

        // Restart self
        Intent restartIntent = new Intent(this, GuardianService.class);
        startService(restartIntent);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}

package com.guardian.app;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1001;
    private TextView statusText;
    private Button btnGrant;

    private static final String[] ALL_PERMISSIONS = {
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.POST_NOTIFICATIONS,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        btnGrant = findViewById(R.id.btnGrant);

        btnGrant.setOnClickListener(v -> requestAllPermissions());

        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();

        // If all permissions granted, start service and close
        if (allPermissionsGranted()) {
            startGuardianService();
            // Minimize app - service runs in background
            moveTaskToBack(true);
        }
    }

    private void updateStatus() {
        if (allPermissionsGranted()) {
            statusText.setText("✅ All permissions granted\nGuardian is running in background.\n\nYou can now access your device from your PC browser at:\nhttp://<your-phone-ip>:8765");
            btnGrant.setText("Open Dashboard Info");
            btnGrant.setOnClickListener(v -> showDashboardInfo());
        } else {
            statusText.setText("Guardian needs permissions to run.\nTap the button below to grant all permissions at once.");
            btnGrant.setText("Grant All Permissions");
            btnGrant.setOnClickListener(v -> requestAllPermissions());
        }
    }

    private void requestAllPermissions() {
        // Step 1: Runtime permissions
        ActivityCompat.requestPermissions(this, ALL_PERMISSIONS, PERMISSION_REQUEST_CODE);

        // Step 2: Special permissions that need Settings pages
        requestSpecialPermissions();
    }

    private void requestSpecialPermissions() {
        // All files access (Android 11+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }

        // Overlay permission
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }

        // Notification listener
        if (!isNotificationListenerEnabled()) {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            Toast.makeText(this, "Please enable Guardian in Notification Access", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isNotificationListenerEnabled() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    private boolean allPermissionsGranted() {
        for (String perm : ALL_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void startGuardianService() {
        if (!isServiceRunning(GuardianService.class)) {
            Intent serviceIntent = new Intent(this, GuardianService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        }
    }

    private boolean isServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) return true;
        }
        return false;
    }

    private void showDashboardInfo() {
        startActivity(new Intent(this, DashboardInfoActivity.class));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        updateStatus();
        if (allPermissionsGranted()) {
            startGuardianService();
            moveTaskToBack(true);
        }
    }
}

package com.guardian.app;

import android.app.Activity;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.widget.TextView;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class DashboardInfoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_info);

        TextView tvInfo = findViewById(R.id.tvInfo);
        String ip = getLocalIpAddress();
        tvInfo.setText(
            "Guardian is running!\n\n" +
            "Open this on your PC browser:\n\n" +
            "http://" + ip + ":8765\n\n" +
            "For outside home access:\n" +
            "1. Install Tailscale on phone\n" +
            "2. Install Tailscale on PC\n" +
            "3. Sign in same account\n" +
            "4. Use Tailscale IP instead\n\n" +
            "Local IP: " + ip
        );
    }

    private String getLocalIpAddress() {
        try {
            for (NetworkInterface intf : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress addr : Collections.list(intf.getInetAddresses())) {
                    if (!addr.isLoopbackAddress() && addr.getHostAddress().contains(".")) {
                        return addr.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {}
        return "unknown";
    }
}
